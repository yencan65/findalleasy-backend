import "dotenv/config";
import bcrypt from "bcryptjs";

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import helmet from "helmet";
import mongoose from "mongoose";
import crypto from "crypto";
import nodemailer from "nodemailer";
import cron from "node-cron";
import fs from "fs";
import path from "path";
import { pathToFileURL } from "url";
import { createServer } from "http";

// WS + Metrics
import { createTelemetryWSS } from "./server/ws/telemetryWS.js";
import { getMetrics } from "./server/utils/metrics.js";

// MODELLER (bu importlar model dosyaların varsa çalışır; yoksa main() içindeki preload ile idare edersin)
import Profile from "./server/models/Profile.js";
import Memory from "./server/models/Memory.js";
import Order from "./server/models/Order.js";

// AI
import OpenAI from "openai";
import * as MistralPkg from "@mistralai/mistralai";
import { GoogleGenerativeAI } from "@google/generative-ai";

// LEARNING
import { syncLearningToMongo } from "./server/core/learningSync.js";
 import vitrinRoutes from "./server/routes/vitrin.js";

// =============================================================================
// Helpers
// =============================================================================
function isFn(v) {
  return typeof v === "function";
}
function ok(res, data = {}, status = 200) {
  return res.status(status).json({ ok: true, ...data });
}
function fail(res, status = 400, data = {}) {
  return res.status(status).json({ ok: false, ...data });
}

// =============================================================================
// Global error hooks
// =============================================================================
process.on("unhandledRejection", (reason, promise) => {
  console.error("💥 Unhandled Promise Rejection:", { reason, promise });
});
process.on("uncaughtException", (err) => {
  console.error("💥 Uncaught Exception:", err);
});

// =============================================================================
// Express app
// =============================================================================
const app = express();
app.set("trust proxy", 1);

const PORT = Number(process.env.PORT || 8080);

// Mongo URI
const MONGO =
  process.env.MONGODB_URI ||
  process.env.MONGO_URI ||
  null;

const FRONTEND_ORIGINS =
  (process.env.FRONTEND_ORIGIN || "http://localhost:5173")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean);

// =============================================================================
// CORS
// =============================================================================
const allowedOrigins = [
  ...new Set([
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:8080",
    "http://127.0.0.1:8080",
    "https://findalleasy.com",
    "https://www.findalleasy.com",
    ...FRONTEND_ORIGINS,
  ]),
];

app.use(
  cors({
    origin(origin, callback) {
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);

      console.warn("🚫 CORS REDDEDİLDİ:", origin);
      // Not throwing hard error here; just deny.
      return callback(null, false);
    },
    credentials: true,
  })
);
app.options("*", cors());

// =============================================================================
// Middleware
// =============================================================================
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(bodyParser.json({ limit: "15mb" }));
app.use("/api/vitrin", vitrinRoutes);

// =============================================================================
// Dynamic auto-loader (optional)
// =============================================================================
export async function loadRouteModules(appInstance) {
  try {
    const routesDir = path.join(process.cwd(), "server", "routes");
    if (!fs.existsSync(routesDir)) return true;

    const files = fs.readdirSync(routesDir);
    for (const file of files) {
      if (!file.endsWith(".js")) continue;

      const routePath = path.join(routesDir, file);
      const fileUrl = pathToFileURL(routePath).href;

      const mod = await import(fileUrl);
      if (mod?.default) {
        const routeName = file.replace(".js", "");
        appInstance.use(`/api/${routeName}`, mod.default);
        console.log(`➡ Route loaded: /api/${routeName}`);
      }
    }
    return true;
  } catch (err) {
    console.error("❌ loadRouteModules error:", err?.message || err);
    return false;
  }
}

export default app;

// =============================================================================
// Router route mounts (safe import)
// =============================================================================
async function registerRouterRoutes(appInstance) {
  if (globalThis.__FAE_ROUTER_ROUTES_REGISTERED) return;
  globalThis.__FAE_ROUTER_ROUTES_REGISTERED = true;

  const strict = String(process.env.FINDALLEASY_STRICT_BOOT || "").toLowerCase() === "1";
  const routeDebug = String(process.env.FINDALLEASY_ROUTE_DEBUG || "") === "1";

  async function safeImportRouter(specOrSpecs, label) {
    const specs = Array.isArray(specOrSpecs) ? specOrSpecs : [specOrSpecs];
    let triedAnyExisting = false;
    let lastErr = null;

    for (const spec of specs) {
      try {
        if (!spec) continue;

        let fileUrl = null;
        if (String(spec).startsWith("file://")) {
          fileUrl = String(spec);
          triedAnyExisting = true;
        } else {
          const absPath = path.isAbsolute(spec)
            ? spec
            : path.join(process.cwd(), String(spec).replace(/^\.\/?/, ""));

          if (!fs.existsSync(absPath)) continue;
          triedAnyExisting = true;
          fileUrl = pathToFileURL(absPath).href;
        }

        const mod = await import(fileUrl);
        const router = mod?.default || mod?.router || null;
        if (!router) throw new Error(`Router export not found (${label || spec})`);
        return router;
      } catch (e) {
        lastErr = e;
        console.error(`❌ Route import FAIL: ${label || spec} ->`, e?.message || e);
        if (strict) throw e;
      }
    }

    if (!triedAnyExisting) {
      if (routeDebug) console.log(`⏭️ Route skip (not found): ${label || "(unknown)"}`);
      return null;
    }
    if (lastErr && strict) throw lastErr;
    return null;
  }

  // NOTE: burada DUPLICATE BLOK OL-MA-YA-CAK. Tek sefer mount ediyoruz.

  {
    const r = await safeImportRouter("./server/routes/verify.js", "verify");
    if (r) appInstance.use("/api/verify", r);
  }
  {
    const r = await safeImportRouter("./server/routes/auth.js", "auth");
    if (r) appInstance.use("/api/auth", r);
  }
  {
    const r = await safeImportRouter("./server/routes/vitrine.js", "vitrine");
    if (r) appInstance.use("/api/vitrine", r);
  }
  {
    const r = await safeImportRouter("./server/routes/suggest.js", "suggest");
    if (r) appInstance.use("/api/suggest", r);
  }
  {
    const r = await safeImportRouter("./server/routes/ai.js", "ai");
    if (r) appInstance.use("/api/ai", r);
  }
  {
    const r = await safeImportRouter("./server/routes/learn.js", "learn");
    if (r) appInstance.use("/api/learn", r);
  }
  {
    const r = await safeImportRouter(
      [
        "./server/routes/product-info.js",
        "./server/routes/productInfo.js",
        "./server/routes/productInfoRoutes.js",
        "./server/routes/product-infoRoutes.js",
      ],
      "product-info"
    );
    if (r) {
      appInstance.use("/api/product-info", r);
      appInstance.use("/api/productInfo", r); // legacy alias
    }
  }
  {
    const r = await safeImportRouter("./server/routes/rewards.js", "rewards");
    if (r) appInstance.use("/api/rewards", r);
  }
  {
    const r = await safeImportRouter("./server/routes/referral.js", "referral");
    if (r) appInstance.use("/api/referral", r);
  }
  {
    const r = await safeImportRouter("./server/routes/click.js", "click");
    if (r) appInstance.use("/api/click", r);
  }
  {
    const r = await safeImportRouter("./server/routes/affiliateCallback.js", "affiliateCallback");
    if (r) appInstance.use("/api/affiliate-callback", r);
  }
  {
    const r = await safeImportRouter("./server/routes/interactions.js", "interactions");
    if (r) appInstance.use("/api/interactions", r);
  }
  {
    const r = await safeImportRouter("./server/routes/coupons.js", "coupons");
    if (r) appInstance.use("/api/coupons", r);
  }
  {
    const r = await safeImportRouter("./server/routes/orderCallback.js", "orderCallback");
    if (r) appInstance.use("/api/order", r);
  }
  {
    const r = await safeImportRouter("./server/routes/wallet.js", "wallet");
    if (r) appInstance.use("/api/wallet", r);
  }
  {
    const r = await safeImportRouter("./server/routes/orders.js", "orders");
    if (r) appInstance.use("/api/orders", r);
  }
  {
    const r = await safeImportRouter("./server/routes/affiliate.js", "affiliate");
    if (r) appInstance.use("/api/affiliate", r);
  }
  {
    const r = await safeImportRouter("./server/routes/vision.js", "vision");
    if (r) appInstance.use("/api/vision", r);
  }
  {
    const r = await safeImportRouter(
      ["./server/routes/revenueRoutes.js", "./server/routes/revenue.js"],
      "revenue"
    );
    if (r) {
      appInstance.use("/api/revenueRoutes", r);
      appInstance.use("/api/revenue", r);
    }
  }
  {
    const r = await safeImportRouter("./server/routes/redirect.js", "redirect");
    if (r) appInstance.use("/api/redirect", r);
  }
  {
    const r = await safeImportRouter("./server/routes/adminTelemetry.js", "adminTelemetry");
    if (r) {
      appInstance.use("/api/adminTelemetry", r);
      appInstance.use("/admin/telemetry", r);
    }
  }
  {
    const r = await safeImportRouter("./server/routes/imageProxy.js", "imageProxy");
    if (r) appInstance.use("/api/imageProxy", r);
  }
  {
    const r = await safeImportRouter("./server/routes/affiliateBridgeS16.js", "affiliateBridgeS16");
    if (r) appInstance.use("/api/aff", r);
  }
}

// =============================================================================
// Inline routes (register once, after DB & reward engine)
// =============================================================================
function registerInlineRoutes(appInstance) {
  if (globalThis.__FAE_INLINE_ROUTES_REGISTERED) return;
  globalThis.__FAE_INLINE_ROUTES_REGISTERED = true;

  // Metrics (if util exists)
  appInstance.get("/metrics", (_req, res) => {
    try {
      const out = isFn(getMetrics) ? getMetrics() : {};
      return ok(res, { metrics: out });
    } catch (e) {
      return fail(res, 500, { error: e?.message || String(e) });
    }
  });

  // Basit watch stub
  appInstance.post("/api/watch", (_req, res) => ok(res, { watch: true }));

  // Models (inline)
  const UserSchema = new mongoose.Schema(
    {
      name: String,
      email: { type: String, unique: true },
      password: String,
      referralCode: String,
      referredBy: String,
      resetCode: String,
      resetExpires: Date,
      createdAt: { type: Date, default: Date.now },
    },
    { strict: false }
  );
  const User = mongoose.models.User || mongoose.model("User", UserSchema);

  const RewardSchema = new mongoose.Schema(
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      amount: Number,
      type: String,
      expireAt: Date,
      createdAt: { type: Date, default: Date.now },
      meta: Object,
      notified3Days: Boolean,
    },
    { strict: false }
  );
  const Reward = mongoose.models.Reward || mongoose.model("Reward", RewardSchema);

  const ReferralSchema = new mongoose.Schema(
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      code: { type: String, unique: true },
      referredUserId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      createdAt: { type: Date, default: Date.now },
    },
    { strict: false }
  );
  const Referral = mongoose.models.Referral || mongoose.model("Referral", ReferralSchema);

  // SMTP mailer
  let transporter = null;
  try {
    const smtpUser = process.env.SMTP_USER || process.env.EMAIL_USER;
    const smtpPass = process.env.SMTP_PASS || process.env.EMAIL_PASS;
    const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
    const smtpPort = Number(process.env.SMTP_PORT || 465);

    if (smtpUser && smtpPass) {
      transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: { user: smtpUser, pass: smtpPass },
        tls: { rejectUnauthorized: false },
      });
      console.log("✅ SMTP bağlantısı hazır");
    } else {
      console.log("⚠️ SMTP kullanıcı bilgileri eksik");
    }
  } catch (e) {
    console.warn("⚠️ SMTP init error:", e?.message || e);
    transporter = null;
  }

  // AI clients
  console.log("🔑 AI Keys Loaded:");
  console.log("   Mistral :", process.env.MISTRAL_API_KEY ? "🟢" : "🔴");
  console.log("   OpenAI  :", process.env.OPENAI_API_KEY ? "🟢" : "🔴");
  console.log("   Gemini  :", process.env.GEMINI_API_KEY ? "🟢" : "🔴");

  let mistral = null;
  try {
    if (process.env.MISTRAL_API_KEY) {
      const MistralCtor = MistralPkg.Mistral || MistralPkg.default || MistralPkg;
      mistral = isFn(MistralCtor) ? new MistralCtor({ apiKey: process.env.MISTRAL_API_KEY }) : null;
    }
  } catch (e) {
    console.warn("⚠️ Mistral init error:", e?.message || e);
    mistral = null;
  }

  let openai = null;
  try {
    if (process.env.OPENAI_API_KEY) openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  } catch (e) {
    console.warn("⚠️ OpenAI init error:", e?.message || e);
    openai = null;
  }

  let genai = null;
  try {
    if (process.env.GEMINI_API_KEY) genai = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  } catch (e) {
    console.warn("⚠️ Gemini init error:", e?.message || e);
    genai = null;
  }

  // UI helpers
  function greetingByHour(hour, locale = "tr", name = "") {
    const n = name ? `${name} ` : "";
    if (hour < 6) return locale === "tr" ? `${n}İyi geceler` : `Good night ${n}`.trim();
    if (hour < 12) return locale === "tr" ? `${n}Günaydın` : `Good morning ${n}`.trim();
    if (hour < 18) return locale === "tr" ? `${n}İyi günler` : `Good afternoon ${n}`.trim();
    return locale === "tr" ? `${n}İyi akşamlar` : `Good evening ${n}`.trim();
  }

  function triggerLines({ locale = "tr", persona = "expert", lastAction = "idle" } = {}) {
    const t = [];
    if (locale === "tr") {
      t.push("Ne arıyorsun? Yazman yeterli, gerisini hallederim.");
      if (persona === "expert") t.push("Bölgen için en uygun ve güvenilir seçenekleri bulabilirim.");
      if (lastAction === "idle") t.push("‘Hey Sono’ de, hemen başlayayım.");
    } else {
      t.push("What are you looking for? Just type it, I’ll handle the rest.");
      if (persona === "expert") t.push("I can fetch trusted best-value options for your region.");
      if (lastAction === "idle") t.push("Say ‘Hey Sono’ to start.");
    }
    return t;
  }

  function buildVitrinCards({ query = "", answer = "", locale = "tr", region = "TR" } = {}) {
    return [
      {
        title: locale === "tr" ? "En uygun & güvenilir" : "Best value & trusted",
        desc: answer || (locale === "tr" ? "Öneriler hazırlanıyor..." : "Preparing suggestions..."),
        cta: locale === "tr" ? "Tıkla" : "Open",
        region,
      },
      {
        title: locale === "tr" ? "Konumuna göre öneri" : "Suggestions by location",
        desc: query || "",
        cta: locale === "tr" ? "Tıkla" : "Open",
        region,
      },
      {
        title: locale === "tr" ? "Diğer satıcılar" : "Other sellers",
        desc: locale === "tr" ? "Karşılaştırmalı alternatifler" : "Comparable alternatives",
        cta: locale === "tr" ? "Tıkla" : "Open",
        region,
      },
    ];
  }

  async function aiChain(prompt, { locale = "tr", region = "TR" } = {}) {
    // 1) Mistral
    try {
      if (mistral && isFn(mistral.chat)) {
        const r = await mistral.chat({
          model: "mistral-medium",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.5,
        });
        const text =
          r?.choices?.[0]?.message?.content ||
          r?.data?.[0]?.message?.content ||
          r?.output ||
          r?.text ||
          "";
        if (text) return { provider: "mistral", text: String(text) };
      }
    } catch (e) {
      console.warn("⚠️ Mistral error:", e?.message || e);
    }

    // 2) OpenAI
    try {
      if (openai) {
        const r = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "Kısa ve net yanıt ver. Kullanıcı ürün/hizmet arıyor." },
            { role: "user", content: `Dil:${locale} Bölge:${region} İstek:${prompt}` },
          ],
          max_tokens: 200,
          temperature: 0.5,
        });
        const text = r?.choices?.[0]?.message?.content || r?.choices?.[0]?.text || "";
        if (text) return { provider: "openai", text: String(text) };
      }
    } catch (e) {
      console.warn("⚠️ OpenAI error:", e?.message || e);
    }

    // 3) Gemini
    try {
      if (genai) {
        const model = genai.getGenerativeModel({ model: "gemini-1.5-flash" });
        const r = await model.generateContent({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
        });
        const text = r?.response?.text?.() || "";
        if (text) return { provider: "gemini", text: String(text) };
      }
    } catch (e) {
      console.warn("⚠️ Gemini error:", e?.message || e);
    }

    return {
      provider: "none",
      text: locale === "tr" ? "Şu an öneri veremiyorum." : "No suggestion currently.",
    };
  }

  // ---------------------------------------------------------------------------
  // Health
  // ---------------------------------------------------------------------------
  appInstance.get("/health", async (_req, res) => {
    try {
      const mongoOk = !!mongoose?.connection && mongoose.connection.readyState === 1;
      return ok(res, {
        mongo: mongoOk,
        openai: !!openai,
        mistral: !!mistral,
        gemini: !!genai,
        time: new Date().toISOString(),
      });
    } catch (e) {
      return fail(res, 500, { error: e?.message || String(e) });
    }
  });

  // ---------------------------------------------------------------------------
  // Greeting + triggers
  // ---------------------------------------------------------------------------
  appInstance.post("/api/greeting", async (req, res) => {
    try {
      const { locale = "tr", name = "", hour } = req.body || {};
      const h = typeof hour === "number" ? hour : new Date().getHours();
      const text = greetingByHour(h, locale, name);
      return ok(res, { text, hour: h });
    } catch {
      return fail(res, 500, { text: "" });
    }
  });

  appInstance.post("/api/triggers", async (req, res) => {
    try {
      const { locale = "tr", persona = "expert", lastAction = "idle" } = req.body || {};
      const lines = triggerLines({ locale, persona, lastAction });
      return ok(res, { lines });
    } catch {
      return fail(res, 500, { lines: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // Personalize
  // ---------------------------------------------------------------------------
  appInstance.post("/api/personalize", async (req, res) => {
    try {
      const { userId = "", sessionId = "", region = "TR", locale = "tr", mood = "calm", ipCity = "" } =
        req.body || {};
      if (MONGO) {
        await Profile.findOneAndUpdate(
          { userId: userId || null, sessionId: sessionId || null },
          { $set: { region, locale, mood, lastSeen: new Date(), ipCity } },
          { upsert: true }
        );
      }
      const cards = buildVitrinCards({ query: "", answer: "", locale, region });
      return ok(res, { cards, mood });
    } catch (e) {
      console.error("personalize error:", e);
      return fail(res, 500, { cards: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // Search (DEV stub gated)
  // ---------------------------------------------------------------------------
  appInstance.post("/api/search", async (req, res) => {
    try {
      const { query = "", region = "TR", locale = "tr", userId = "", sessionId = "", offset = 0, limit = 20 } =
        req.body || {};
      const off = Number(offset) || 0;
      const lim = Math.min(50, Number(limit) || 20);

      if (MONGO && (userId || sessionId)) {
        await Profile.findOneAndUpdate(
          { userId: userId || null, sessionId: sessionId || null },
          {
            $push: { lastQueries: { q: query, at: new Date() } },
            $set: { lastSeen: new Date(), region, locale },
          },
          { upsert: true }
        );
      }

      const ALLOW_STUBS = String(process.env.FINDALLEASY_ALLOW_STUBS || "") === "1";
      if (!ALLOW_STUBS) {
        const cards = buildVitrinCards({ query, answer: "", locale, region });
        return fail(res, 501, {
          error: "SEARCH_NOT_IMPLEMENTED",
          cards,
          results: [],
          nextOffset: 0,
          hasMore: false,
          total: 0,
        });
      }

      const total = 100;
      const all = Array.from({ length: total }, (_, i) => ({
        id: `alt-${i + 1}`,
        title: `${query || "Alternatif"} #${i + 1}`,
        price: Math.round(50 + (i % 7) * 200),
        deeplink: "https://example.com/product/" + (i + 1),
        rating: ((i % 10) + 10) / 10,
        provider: i % 2 ? "Trendyol" : "Global",
        region,
      }));
      const slice = all.slice(off, off + lim);
      const nextOffset = off + slice.length;
      const hasMore = nextOffset < total;

      const cards = buildVitrinCards({ query, answer: "", locale, region });
      return ok(res, { cards, results: slice, nextOffset, hasMore, total });
    } catch (e) {
      console.error("search error:", e);
      return fail(res, 500, { cards: [], results: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // AI route (inline)
  // ---------------------------------------------------------------------------
  let aiRecentCalls = [];
  function aiRateAllowed() {
    const now = Date.now();
    aiRecentCalls = aiRecentCalls.filter((t) => now - t < 1000);
    if (aiRecentCalls.length >= 3) return false;
    aiRecentCalls.push(now);
    return true;
  }

  appInstance.post("/api/ai", async (req, res) => {
    try {
      if (!aiRateAllowed()) {
        return fail(res, 429, {
          answer: "Şu anda çok fazla istek alıyorum, birkaç saniye sonra tekrar dene.",
          cards: [],
        });
      }

      const body = req.body || {};
      let { message = "", region = "TR", locale = "tr", userId = "" } = body;

      let prompt = String(message || "").trim();
      if (!prompt) return ok(res, { provider: "none", answer: "", cards: [] });

      const MAX_PROMPT_LEN = 800;
      if (prompt.length > MAX_PROMPT_LEN) prompt = prompt.slice(0, MAX_PROMPT_LEN);

      locale = String(locale || "tr").slice(0, 8).toLowerCase();
      region = String(region || "TR").slice(0, 8).toUpperCase();

      let provider = "none";
      let text = "";

      try {
        const aiResult = await aiChain(prompt, { locale, region });
        provider = aiResult?.provider || "unknown";
        text = String(aiResult?.text || "").trim();
      } catch (err) {
        console.error("aiChain hata:", err);
        provider = "fallback";
        text = "Gerçek AI şu an sessiz ama yine de senin için bakıyorum.";
      }

      let cards = [];
      try {
        const out = buildVitrinCards({ query: prompt, answer: text, locale, region });
        if (Array.isArray(out)) cards = out;
      } catch (err) {
        console.error("buildVitrinCards hata:", err);
      }

      try {
        if (MONGO && userId) {
          await Profile.findOneAndUpdate(
            { userId },
            { $push: { lastQueries: { q: prompt, at: new Date() } } },
            { upsert: true }
          );
        }
      } catch (err) {
        console.warn("Profile.lastQueries kaydı sırasında hata:", err);
      }

      try {
        if (MONGO && userId && text) {
          await Memory.create({
            userId,
            query: prompt.slice(0, 1200),
            answer: String(text).slice(0, 4000),
            locale,
            region,
          });
        }
      } catch (err) {
        console.warn("Memory kayıt hatası:", err);
      }

      return ok(res, { provider, answer: text, cards });
    } catch (e) {
      console.error("AI route genel hata:", e);
      return fail(res, 500, { answer: "Gerçek AI şu anda sessiz.", cards: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // Vision
  // ---------------------------------------------------------------------------
  appInstance.post("/api/vision", async (req, res) => {
    try {
      const { imageBase64 = "", locale = "tr", region = "TR" } = req.body || {};
      if (!imageBase64) return fail(res, 400, { error: "imageBase64 required" });
      let extracted = "";

      if (genai) {
        try {
          const model = genai.getGenerativeModel({ model: "gemini-1.5-flash" });
          const cleaned = imageBase64.replace(/^data:image\/\w+;base64,/, "");
          const r = await model.generateContent({
            contents: [
              {
                role: "user",
                parts: [
                  { text: locale === "tr" ? "Bu görseli kısa tanımla." : "Briefly describe this image." },
                  { inlineData: { data: cleaned, mimeType: "image/png" } },
                ],
              },
            ],
          });
          extracted = r?.response?.text?.() || "";
        } catch (ge) {
          console.warn("⚠️ Gemini vision error:", ge?.message || ge);
        }
      }

      const cards = buildVitrinCards({ query: extracted, answer: "", locale, region });
      return ok(res, { query: extracted || "", cards });
    } catch (e) {
      console.error("vision error:", e);
      return fail(res, 500, { cards: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // Voice
  // ---------------------------------------------------------------------------
  appInstance.post("/api/voice", async (req, res) => {
    try {
      const { transcript = "", region = "TR", locale = "tr" } = req.body || {};
      const t = String(transcript || "").trim();
      if (!t) return ok(res, { type: "voice", provider: "none", answer: "", cards: [] });

      const out = await aiChain(t, { locale, region });
      const cards = buildVitrinCards({ query: t, answer: out.text, locale, region });
      return ok(res, { type: "voice", provider: out.provider, answer: out.text, cards });
    } catch (e) {
      console.error("voice error:", e);
      return fail(res, 500, { answer: "", cards: [] });
    }
  });

  // ---------------------------------------------------------------------------
  // Auth legacy + custom
  // ---------------------------------------------------------------------------
  appInstance.post("/api/auth/legacy-signup", async (req, res) => {
    try {
      const { email = "", password = "", referral = "" } = req.body || {};
      if (!email || !password) return fail(res, 400, { error: "email & password required" });

      const exists = await User.findOne({ email }).exec();
      if (exists) return fail(res, 400, { error: "user exists" });

      const hashed = crypto.createHash("sha256").update(password).digest("hex");
      const referralCode = crypto.randomBytes(4).toString("hex");

      const user = await User.create({
        email,
        password: hashed,
        referralCode,
        referredBy: referral || null,
      });

      await Reward.create({
        userId: user._id,
        amount: 1,
        type: "signup",
        expireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000),
        meta: { note: "ilk giriş %1 indirim" },
      });

      if (referral) {
        const inviter = await User.findOne({ referralCode: referral }).lean();
        if (inviter) {
          await Reward.create({
            userId: inviter._id,
            amount: 0.5,
            type: "referral",
            expireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000),
            meta: { invited: user.email },
          });
        }
      }

      return ok(res, { userId: String(user._id), email: user.email, referralCode });
    } catch (e) {
      console.error("legacy signup error:", e);
      return fail(res, 500, { error: "signup error" });
    }
  });

  appInstance.post("/api/auth/legacy-login", async (req, res) => {
    try {
      const { email = "", password = "" } = req.body || {};
      if (!email || !password) return fail(res, 400, { error: "email & password required" });

      const hashed = crypto.createHash("sha256").update(password).digest("hex");
      const user = await User.findOne({ email, password: hashed }).exec();
      if (!user) return fail(res, 401, { error: "invalid credentials" });

      const active = await Reward.find({ userId: user._id, expireAt: { $gte: new Date() } }).lean();
      const rewards = (active || []).reduce((s, r) => s + (r.amount || 0), 0);

      return ok(res, {
        userId: String(user._id),
        email: user.email,
        referralCode: user.referralCode,
        rewards: Number(rewards.toFixed(2)),
      });
    } catch (e) {
      console.error("legacy login error:", e);
      return fail(res, 500, { error: "login error" });
    }
  });

  // Request reset code
  function generateCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  appInstance.post("/api/auth/request-reset", async (req, res) => {
    try {
      const { email } = req.body || {};
      const user = await User.findOne({ email }).exec();
      if (!user) return res.status(404).json({ success: false, message: "Bu e-posta kayıtlı değil." });

      const code = generateCode();
      user.resetCode = code;
      user.resetExpires = new Date(Date.now() + 15 * 60 * 1000);
      await user.save();

      if (!transporter) return res.status(500).json({ success: false, message: "E-posta servisi devre dışı." });

      await transporter.sendMail({
        from: process.env.FROM_EMAIL || process.env.SMTP_USER,
        to: email,
        subject: "FindAllEasy | Şifre Yenileme Kodun",
        html: `
          <div style="font-family:sans-serif;background:#111;padding:20px;color:#fff;">
            <h2 style="color:#ffd347;">FindAllEasy | Şifre Yenileme</h2>
            <p>Şifreni yenilemek için doğrulama kodun:</p>
            <div style="font-size:24px;letter-spacing:4px;margin:16px 0;"><b>${code}</b></div>
            <p>Bu kod <b>15 dakika</b> boyunca geçerlidir.</p>
          </div>`,
      });

      return res.json({ success: true, message: "Kod e-posta adresine gönderildi." });
    } catch (err) {
      console.error("E-posta gönderim hatası:", err);
      return res.status(500).json({ success: false, message: "E-posta gönderilemedi." });
    }
  });

  appInstance.post("/api/auth/verify-reset", async (req, res) => {
    try {
      const { email, code } = req.body || {};
      const user = await User.findOne({ email }).exec();
      if (!user || user.resetCode !== code || !user.resetExpires || user.resetExpires < new Date()) {
        return res.json({ verified: false, message: "Kod geçersiz veya süresi dolmuş." });
      }
      return res.json({ verified: true });
    } catch (err) {
      console.error("Kod doğrulama hatası:", err);
      return res.status(500).json({ verified: false, message: "Doğrulama hatası." });
    }
  });

  appInstance.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, newPassword } = req.body || {};
      const user = await User.findOne({ email }).exec();
      if (!user) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });

      if (!user.resetCode || !user.resetExpires || user.resetExpires < new Date())
        return res.status(400).json({ success: false, message: "Kod geçersiz veya süresi dolmuş." });

      const salt = await bcrypt.genSalt(10);
      const hashed = await bcrypt.hash(newPassword, salt);

      user.password = hashed;
      user.resetCode = null;
      user.resetExpires = null;
      await user.save();

      return res.json({ success: true, message: "Şifre başarıyla değiştirildi." });
    } catch (err) {
      console.error("Şifre yenileme hatası:", err);
      return res.status(500).json({ success: false, message: "Şifre güncellenemedi." });
    }
  });

  appInstance.post("/api/auth/custom-signup", async (req, res) => {
    try {
      const { name, email, password, referral } = req.body || {};
      if (!email || !password) return fail(res, 400, { error: "email & password required" });

      const exists = await User.findOne({ email }).exec();
      if (exists) return fail(res, 400, { error: "user exists" });

      const hashed = await bcrypt.hash(password, 10);
      const referralCode = crypto.randomBytes(4).toString("hex");

      const user = await User.create({
        name,
        email,
        password: hashed,
        referralCode,
        referredBy: referral || null,
      });

      return ok(res, { userId: String(user._id), name: user.name, email: user.email, referralCode });
    } catch (err) {
      console.error("signup error:", err);
      return fail(res, 500, { error: "signup error" });
    }
  });

  appInstance.post("/api/auth/custom-login", async (req, res) => {
    try {
      const { email, password } = req.body || {};
      if (!email || !password) return res.status(400).json({ success: false, message: "E-posta ve şifre gerekli." });

      const user = await User.findOne({ email }).exec();
      if (!user) return res.status(401).json({ success: false, message: "E-posta kayıtlı değil." });

      const match = await bcrypt.compare(password, user.password || "");
      if (!match) return res.status(401).json({ success: false, message: "Şifre hatalı." });

      return res.json({
        success: true,
        message: "Giriş başarılı.",
        userId: String(user._id),
        name: user.username || user.name || user.email.split("@")[0],
      });
    } catch (err) {
      console.error("login error:", err);
      return res.status(500).json({ success: false, message: "Sunucu hatası." });
    }
  });

  // ---------------------------------------------------------------------------
  // Orders stats
  // ---------------------------------------------------------------------------
  appInstance.get("/api/orders/stats", async (req, res) => {
    try {
      const { userId } = req.query || {};
      if (!userId) return fail(res, 400, { error: "userId required" });

      const completedCount = await Order.countDocuments({ userId: String(userId), status: "paid" }).exec();
      return ok(res, { completedCount });
    } catch (e) {
      console.error("orders/stats error:", e);
      return fail(res, 500, { error: "orders stats error" });
    }
  });

  // ---------------------------------------------------------------------------
  // Coupons
  // ---------------------------------------------------------------------------
  appInstance.post("/api/coupons/create", async (req, res) => {
    try {
      const { userId, amount } = req.body || {};
      if (!userId || !amount) return fail(res, 400, { error: "userId ve amount gereklidir" });

      const code = "FAE-" + crypto.randomBytes(3).toString("hex").toUpperCase();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      return ok(res, { code, amount: Number(amount), expiresAt });
    } catch (e) {
      console.error("coupon create error:", e);
      return fail(res, 500, { error: "coupon create error" });
    }
  });

  // ---------------------------------------------------------------------------
  // Badges
  // ---------------------------------------------------------------------------
  appInstance.get("/api/badges", async (req, res) => {
    try {
      const { userId } = req.query || {};
      if (!userId) return ok(res, { badges: [] });

      const completed = await Order.countDocuments({ userId: String(userId), status: "paid" }).exec();
      const badges = [];
      if (completed >= 1) badges.push({ code: "first_purchase", label: "İlk Alışverişini Tamamladı" });
      if (completed >= 5) badges.push({ code: "loyal_buyer", label: "Sadık Müşteri" });

      return ok(res, { badges });
    } catch (e) {
      console.error("badges error:", e);
      return fail(res, 500, { error: "badges error" });
    }
  });

  // ---------------------------------------------------------------------------
  // Rewards list + redeem
  // ---------------------------------------------------------------------------
  appInstance.get("/api/rewards", async (req, res) => {
    try {
      const { userId } = req.query || {};
      if (!userId) return fail(res, 400, { error: "userId required" });

      const list = await Reward.find({ userId, expireAt: { $gte: new Date() } }).sort({ expireAt: 1 }).lean();
      const total = (list || []).reduce((s, z) => s + (z.amount || 0), 0);
      return ok(res, { total, list });
    } catch (e) {
      console.error("rewards error:", e);
      return fail(res, 500, { error: "rewards error" });
    }
  });

  appInstance.post("/api/rewards/redeem", async (req, res) => {
    try {
      const { userId, amount = 0 } = req.body || {};
      if (!userId || !amount) return fail(res, 400, { error: "userId & amount required" });

      const userDoc = await User.findById(userId).lean();
      if (!userDoc) return fail(res, 403, { error: "login required for discount" });

      const active = await Reward.find({ userId, expireAt: { $gte: new Date() } }).sort({ expireAt: 1 }).lean();
      const available = (active || []).reduce((s, z) => s + (z.amount || 0), 0);
      if (available < amount) return fail(res, 400, { error: "insufficient reward" });

      let remaining = amount;
      for (const r of active) {
        if (remaining <= 0) break;
        const use = Math.min(remaining, r.amount);
        remaining -= use;
        await Reward.updateOne({ _id: r._id }, { $inc: { amount: -use } });
      }
      return ok(res, { used: amount });
    } catch (e) {
      console.error("redeem error:", e);
      return fail(res, 500, { error: "redeem error" });
    }
  });

  // ---------------------------------------------------------------------------
  // Cron cleanup + notify
  // ---------------------------------------------------------------------------
  if (transporter) {
    cron.schedule("0 0 * * *", async () => {
      try {
        const now = new Date();
        await Reward.deleteMany({ $or: [{ amount: { $lte: 0 } }, { expireAt: { $lte: now } }] });

        const threeDays = new Date(now.getTime() + 3 * 24 * 3600 * 1000);
        const soon = await Reward.find({
          expireAt: { $gte: now, $lte: threeDays },
          notified3Days: { $ne: true },
        }).lean();

        for (const r of soon) {
          const user = await User.findById(r.userId).lean();
          if (!user?.email) continue;

          await transporter.sendMail({
            from: process.env.FROM_EMAIL || process.env.SMTP_USER,
            to: user.email,
            subject: "FindAllEasy: ödülün 3 gün içinde sona eriyor",
            html: `<div style="font:14px/1.6 Arial">
                    <h3>Merhaba,</h3>
                    <p>Hesabındaki <b>${r.amount}</b> ödül yakında sona erecek.</p>
                    <p>Son kullanım: <b>${(r.expireAt || now).toISOString().slice(0, 10)}</b></p>
                   </div>`,
          });

          await Reward.updateOne({ _id: r._id }, { $set: { notified3Days: true } });
        }
        console.log("cron ok");
      } catch (e) {
        console.warn("cron error:", e?.message || e);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Referral
  // ---------------------------------------------------------------------------
  appInstance.post("/api/referral/create", async (req, res) => {
    try {
      const { userId } = req.body || {};
      if (!userId) return fail(res, 400, { error: "userId required" });
      const code = crypto.randomBytes(5).toString("hex");
      await Referral.create({ userId, code });
      return ok(res, { code, url: `${process.env.PUBLIC_URL || "https://findalleasy.com"}/invite?c=${code}` });
    } catch (e) {
      console.error("referral create error:", e);
      return fail(res, 500);
    }
  });

  appInstance.post("/api/referral/use", async (req, res) => {
    try {
      const { newUserId, code } = req.body || {};
      if (!newUserId || !code) return fail(res, 400, { error: "params required" });

      const ref = await Referral.findOne({ code }).lean();
      if (!ref) return fail(res, 404, { error: "invalid code" });

      await Referral.updateOne({ code }, { $set: { referredUserId: newUserId } });
      return ok(res, { used: true });
    } catch (e) {
      console.error("referral use error:", e);
      return fail(res, 500);
    }
  });

  appInstance.post("/api/referral/invite", async (req, res) => {
    try {
      const { userId } = req.body || {};
      if (!userId) return fail(res, 400, { error: "userId required" });

      const code = crypto.randomBytes(5).toString("hex");
      await Referral.create({ userId, code });
      return ok(res, { code });
    } catch (e) {
      console.error("referral invite error:", e);
      return fail(res, 500, { error: "referral invite error" });
    }
  });

  // ---------------------------------------------------------------------------
  // Payment webhook (stub signature)
  // ---------------------------------------------------------------------------
  function verifyProviderSignature(_req) {
    return true;
  }

  appInstance.post("/api/payment/webhook", async (req, res) => {
    try {
      if (!verifyProviderSignature(req)) return fail(res, 401);

      const { orderId, userId, amount = 0, currency = "TRY", provider = "iyzico", referralCode = null, event = "payment_succeeded" } =
        req.body || {};
      if (!orderId || !userId) return fail(res, 400, { error: "orderId & userId required" });

      let order = await Order.findOne({ providerOrderId: orderId });
      if (!order) {
        order = await Order.create({
          userId,
          amount,
          currency,
          provider,
          providerOrderId: orderId,
          status: "pending",
          referredBy: referralCode || null,
        });
      }

      if (event === "payment_succeeded") {
        const count = await Order.countDocuments({ userId, status: "paid" });
        if (count === 0) {
          const buyerDiscount = Math.round(amount * 0.01 * 100) / 100;
          await Reward.create({
            userId,
            amount: -buyerDiscount,
            type: "discount_applied",
            expireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000),
          });
        }

        if (referralCode) {
          const inviter = await User.findOne({ referralCode }).lean();
          if (inviter) {
            const invBonus = Math.round(amount * 0.005 * 100) / 100;
            await Reward.create({
              userId: inviter._id,
              amount: invBonus,
              type: "referral_bonus",
              expireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000),
            });
          }
        }

        order.status = "paid";
        order.paidAt = new Date();
        await order.save();
      }

      return ok(res, { handled: true });
    } catch (e) {
      console.error("payment webhook error:", e);
      return fail(res, 500);
    }
  });

  // ---------------------------------------------------------------------------
  // Memory API
  // ---------------------------------------------------------------------------
  appInstance.get("/api/memory", async (req, res) => {
    try {
      const { userId } = req.query || {};
      if (!userId) return fail(res, 400, { error: "userId required" });
      const items = await Memory.find({ userId }).lean();
      return ok(res, { items });
    } catch (e) {
      console.error("memory load error:", e);
      return fail(res, 500);
    }
  });

  appInstance.post("/api/memory/save", async (req, res) => {
    try {
      const { userId, items = [] } = req.body || {};
      if (!userId) return fail(res, 400, { error: "userId required" });
      for (const { key, value } of items) {
        await Memory.updateOne({ userId, key }, { $set: { value, lastUpdated: new Date() } }, { upsert: true });
      }
      return ok(res, { saved: items.length });
    } catch (e) {
      console.error("memory save error:", e);
      return fail(res, 500);
    }
  });

  // Translate (stub)
  appInstance.post("/api/translate", async (req, res) => {
    try {
      const { text = "", targetLang = "tr" } = req.body || {};
      return ok(res, { translated: text, targetLang });
    } catch (e) {
      console.error("translate error:", e);
      return fail(res, 500);
    }
  });

  // Debug panel
  appInstance.get("/api/debug/s10", async (_req, res) => {
    try {
      const lastProfiles = await Profile.find({}).sort({ lastSeen: -1 }).limit(20).lean();
      const lastMemory = await Memory.find({}).sort({ _id: -1 }).limit(20).lean();

      const rewardStats = await Reward.aggregate([
        { $match: {} },
        { $group: { _id: "$type", total: { $sum: "$amount" }, count: { $sum: 1 } } },
      ]);

      const orderStats = await Order.aggregate([
        { $match: {} },
        { $group: { _id: "$status", count: { $sum: 1 }, total: { $sum: "$amount" } } },
      ]);

      const mem = process.memoryUsage();
      const cpu = process.cpuUsage();
      const adapterEngineStats = globalThis?.AdapterStats || {};

      return res.json({
        ok: true,
        system: {
          uptime: process.uptime(),
          cpu,
          memory: { rss: mem.rss, heap: mem.heapUsed, heapTotal: mem.heapTotal },
          mongo: mongoose?.connection?.readyState === 1,
        },
        engine: { adapters: adapterEngineStats },
        rewards: rewardStats,
        orders: orderStats,
        lastProfiles,
        lastMemory,
      });
    } catch (e) {
      console.error("S10 DEBUG ERROR:", e);
      return res.status(500).json({ ok: false, error: e?.message || String(e) });
    }
  });
}

// =============================================================================
// MAIN (DB -> RewardEngine -> routes -> listen)
// =============================================================================
async function main() {
  if (!MONGO) {
    console.error("❌ env.MONGODB_URI veya MONGO_URI tanımlı değil. Mongo olmadan sistem çalıştırmak mantıksız.");
    process.exit(1);
  }

  // DB connect
  try {
    await mongoose.connect(MONGO, { serverSelectionTimeoutMS: 10000 });
    console.log("✅ MongoDB bağlantısı başarılı");
  } catch (e) {
    console.error("❌ MongoDB bağlantı hatası:", e?.message || e);
    process.exit(1);
  }

  // settle guard (optional)
  try {
    if (typeof mongoose.connection?.asPromise === "function") {
      await mongoose.connection.asPromise();
    }
  } catch (e) {
    console.warn("⚠️ mongoose settle warn:", e?.message || e);
  }

  globalThis.mongoose = mongoose;

  // Model preload (optional)
  try {
    await Promise.allSettled([
      import("./server/models/User.js"),
      import("./server/models/Order.js"),
      import("./server/models/WalletTransaction.js"),
    ]);
  } catch (e) {
    console.warn("⚠️ model preload warn:", e?.message || e);
  }

  // RewardEngine init (soft)
  try {
    const rewardEngineMod = await import("./server/core/rewardEngine.js");
    const ensureModel = rewardEngineMod.ensureModel || rewardEngineMod.default?.ensureModel;
    const systemStartupCheck = rewardEngineMod.systemStartupCheck || rewardEngineMod.default?.systemStartupCheck;

    if (typeof ensureModel === "function") {
      const okEnsure = await ensureModel();
      if (!okEnsure) console.warn("⚠️ RewardEngine ensureModel => false (devam)");
    }
    if (typeof systemStartupCheck === "function") {
      await systemStartupCheck();
    } else {
      console.warn("⚠️ rewardEngine.systemStartupCheck bulunamadı");
    }
    console.log("✅ Reward Engine S16 boot tamam");
  } catch (e) {
    console.warn("⚠️ RewardEngine boot error (soft):", e?.message || e);
  }

  // Routes
  await registerRouterRoutes(app);
  registerInlineRoutes(app);

  // Optional: auto-loader
  try {
    const AUTO_ROUTE_LOADER = String(process.env.FINDALLEASY_AUTO_ROUTE_LOADER || "0") !== "0";
    if (AUTO_ROUTE_LOADER) await loadRouteModules(app);
  } catch (e) {
    console.warn("⚠️ AUTO_ROUTE_LOADER warn:", e?.message || e);
  }

  // Learning sync
  try {
    setInterval(syncLearningToMongo, 300000);
  } catch {}

  // HTTP + WS
  const httpServer = createServer(app);
  try {
    createTelemetryWSS(httpServer);
  } catch (e) {
    console.warn("⚠️ Telemetry WS init warn:", e?.message || e);
  }

  httpServer.listen(PORT, () => {
    console.log("HTTP+WS server running on", PORT);
  });
}

main().catch((e) => {
  console.error("💥 MAIN_FATAL:", e?.message || e);
  process.exit(1);
});
