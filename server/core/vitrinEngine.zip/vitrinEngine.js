// BACKEND/core/vitrinEngine.js
// FindAllEasy Vitrin Motoru — S21 GOD ENGINE · H E R K Ü L MODU
// ------------------------------------------------------------------
// KURALLAR:
// - Mevcut işlevler SİLİNMİYOR, sadece güçlendiriliyor.
// - BEST motoru: S10.5 + S11 + S11.2 + S11.3 → TEK S21 GOD BLOĞU
// - SMART / OTHERS hiçbir koşulda BEST’i geçemez (fiyat + kalite + güven).
// - Fusion, cache, mock, safe mode, providerLogo, metaScore, personalization,
//   commission ve badge motorları aynen korunur, sadece tek beyne bağlanır.
// ------------------------------------------------------------------

// S35 GLOBAL PRICE NORMALIZER (harici normalizer dosyasından)
import { normalizeAdapterResultsS35 } from "./normalizerS35.js";

import stringSimilarity from "string-similarity";
import { getUserMemory, updateUserMemory } from "./learningMemory.js";
// 🔥 ANA MOTOR: S100 + S200 çekirdeği burada
import { runAdapters, s40_safeDetectIntent } from "./adapterEngine.js";
import {
  decorateResultsWithCommission,
  safeDecorateResultsWithCommission,
  providerPriority,
} from "./commissionEngine.js";
import { decorateWithBadges } from "./badgeEngine.js";
import { recordProviderClick } from "./providerLearning.js";
import {
  buildBestCardExplanation,
  buildSmartCardExplanation,
  buildOthersCardExplanation,
} from "../intelligence/explanationBuilder.js";
import { detectIntent } from "./intentEngine.js";
import { safeComputeFinalUserPrice } from "./priceEngine.js";
import { buildMemoryProfile, applyPersonalizationScore } from "./aiPipeline.js";
import { relatedMap } from "./relatedMap.js";

// ---------------------------------------------------------
// 🔒 S21 SAFE NORMALIZER — Kart için minimum alan garantisi
// ---------------------------------------------------------
function s21_sanitizeItem(item) {
  if (!item || typeof item !== "object") return null;

  const id =
    item.id ||
    item._id ||
    item.stableId ||
    item.url ||
    (item.title ? String(item.title).slice(0, 64) : null);

  const providerKey = item.providerKey || item.provider || "unknown";
  const provider = item.provider || providerKey || "unknown";

  let price = item.price;
  if (!isValidNumber(price) || price < 0) {
    price = 0;
  }

  let image =
    (Array.isArray(item.images) && item.images[0]) ||
    item.image ||
    item.thumbnail ||
    "";

  const rating = isValidNumber(item.rating) ? item.rating : 0;
  const trustScore = isValidNumber(item.trustScore)
    ? item.trustScore
    : 0;

  return {
    ...item,
    id,
    providerKey,
    provider,
    price,
    image,
    rating,
    trustScore,
    title: item.title ? String(item.title).trim() : "",
    commissionMeta: item.commissionMeta || {},
  };
}

// ---------------------------------------------------------
// 🔥 Küçük yardımcılar
// ---------------------------------------------------------
function isValidNumber(n) {
  return typeof n === "number" && Number.isFinite(n);
}

function asArray(val) {
  if (!val) return [];
  return Array.isArray(val) ? val : [val];
}

function getProviderTrust(providerKey) {
  const key = String(providerKey || "unknown").toLowerCase();
  const prio = providerPriority[key] ?? providerPriority.unknown ?? 3;
  return 0.6 + ((Math.max(1, Math.min(5, prio)) - 1) / 4) * 0.4;
}

function computePriceNorm(priceRaw) {
  if (!isValidNumber(priceRaw)) return 0;
  const price = Math.max(0, priceRaw);
  return 1 / (price + 1);
}

function computeFinalScore(item) {
  const pers = item.qualityScorePersonal || item.qualityScore || 0;
  const qual = item.qualityScore || 0;

  const price = isValidNumber(item.finalUserPrice)
    ? item.finalUserPrice
    : isValidNumber(item.price)
    ? item.price
    : Infinity;

  const priceNorm = computePriceNorm(price);

  return pers * 0.5 + qual * 0.3 + priceNorm * 0.2;
}

// ---------------------------------------------------------
// 🔥 S11 — FULL PROVIDER LOGO DICTIONARY (100+ provider)
// ---------------------------------------------------------
const providerLogos = {
  // 🇹🇷 Büyük Türk Pazarları
  trendyol: "/logos/trendyol.svg",
  ty: "/logos/trendyol.svg",

  hepsiburada: "/logos/hepsiburada.svg",
  hb: "/logos/hepsiburada.svg",

  n11: "/logos/n11.svg",
  n11com: "/logos/n11.svg",

  ciceksepeti: "/logos/ciceksepeti.svg",
  cicek: "/logos/ciceksepeti.svg",
  cs: "/logos/ciceksepeti.svg",

  akakce: "/logos/akakce.svg",
  gittigidiyor: "/logos/gittigidiyor.svg",

  // 🇹🇷 Yemek / Market
  getir: "/logos/getir.svg",
  getirbuyuk: "/logos/getir.svg",
  yemeksepeti: "/logos/yemeksepeti.svg",
  banabi: "/logos/getir.svg",
  trendyolgo: "/logos/trendyol.svg",

  // 🇹🇷 Araç / Hizmet
  armut: "/logos/armut.svg",
  arabam: "/logos/arabam.svg",
  sahibinden: "/logos/sahibinden.svg",

  // 🇹🇷 Tur / Bilet
  biletix: "/logos/biletix.svg",
  passo: "/logos/passo.svg",
  biletino: "/logos/biletino.svg",
  mngtur: "/logos/mngtur.svg",
  etstur: "/logos/etstur.svg",

  // 🌍 Global Marketplaces
  amazon: "/logos/amazon.svg",
  amazontr: "/logos/amazon.svg",
  aliexpress: "/logos/aliexpress.svg",
  ebay: "/logos/ebay.svg",
  etsy: "/logos/etsy.svg",
  allegro: "/logos/allegro.svg",
  walmart: "/logos/walmart.svg",
  bestbuy: "/logos/bestbuy.svg",
  target: "/logos/target.svg",

  // 🌍 Otel / Uçak
  booking: "/logos/booking.svg",
  bookingcom: "/logos/booking.svg",

  agoda: "/logos/agoda.svg",
  trivago: "/logos/trivago.svg",
  hotels: "/logos/hotels.svg",

  skyscanner: "/logos/skyscanner.svg",
  kiwi: "/logos/kiwi.svg",

  turkishairlines: "/logos/turkishairlines.svg",
  thy: "/logos/turkishairlines.svg",
  pegasus: "/logos/pegasus.svg",

  // 🌍 Tur / Etkinlik
  tripadvisor: "/logos/tripadvisor.svg",
  viator: "/logos/viator.svg",

  // 🌍 Moda / Spor
  zara: "/logos/zara.svg",
  hm: "/logos/hm.svg",
  lcw: "/logos/lcw.svg",
  defacto: "/logos/defacto.svg",
  koton: "/logos/koton.svg",
  adidas: "/logos/adidas.svg",
  nike: "/logos/nike.svg",
  decathlon: "/logos/decathlon.svg",

  // 🌍 Teknoloji
  google: "/logos/google.svg",
  serpapi: "/logos/google.svg",

  // Harita
  osm: "/logos/osm.svg",
  openstreetmap: "/logos/osm.svg",

  // Fallback
  default: "/logos/default.svg",
};

// ---------------------------------------------------------
// 🔥 S11 — ULTRA PROVIDER LOGO INJECTION ENGINE
// ---------------------------------------------------------
function injectProviderLogo(item) {
  if (!item) return item;

  const keys = Object.keys(providerLogos);

  let raw = String(item.provider || item.adapterSource || "")
    .toLowerCase()
    .trim()
    .replace("www.", "");

  if (!raw && item.url) {
    raw = item.url.replace(/^https?:\/\//, "").split("/")[0];
  }

  let key = raw
    .replace(".com", "")
    .replace(".tr", "")
    .replace(".net", "")
    .replace(".org", "")
    .replace(/[^a-z0-9]/g, "");

  if (providerLogos[key]) {
    return { ...item, providerLogo: providerLogos[key] };
  }

  const soft = keys.find((k) => key.includes(k));
  if (soft) {
    return { ...item, providerLogo: providerLogos[soft] };
  }

  if (item.url) {
    let domain = item.url
      .replace(/^https?:\/\//, "")
      .split("/")[0]
      .replace("www.", "");

    domain = domain
      .replace(".com", "")
      .replace(".tr", "")
      .replace(/[^a-z0-9]/g, "");

    const domainMatch = keys.find((k) => domain.includes(k));
    if (domainMatch) {
      return { ...item, providerLogo: providerLogos[domainMatch] };
    }
  }

  try {
    const similarity = keys
      .map((k) => ({
        k,
        score: stringSimilarity.compareTwoStrings(key, k),
      }))
      .sort((a, b) => b.score - a.score);

    if (similarity[0].score >= 0.42) {
      return { ...item, providerLogo: providerLogos[similarity[0].k] };
    }
  } catch {}

  return { ...item, providerLogo: providerLogos.default };
}

// ---------------------------------------------------------
// 🔥 Vitrin Cache (S8.4 → userId dahil)
// ---------------------------------------------------------
const vitrinCache = new Map();
const VITRIN_CACHE_TTL_MS = 60_000;

function getCachedVitrin(query, region, userId = null) {
  const key = `${String(query || "null")}:${String(region || "global")}:${
    userId || "anon"
  }`;
  const entry = vitrinCache.get(key);
  if (!entry) return null;

  if (Date.now() - entry.time > VITRIN_CACHE_TTL_MS) {
    vitrinCache.delete(key);
    return null;
  }
  return entry.data;
}

function setCachedVitrin(query, region, userId = null, data) {
  const key = `${String(query || "null")}:${String(region || "global")}:${
    userId || "anon"
  }`;
  vitrinCache.set(key, { data, time: Date.now() });
}

// ---------------------------------------------------------
// 🔥 Kategori Normalize (S120-safe)
// ---------------------------------------------------------
function normalizeCategory(item, categoryHint = null) {
  if (categoryHint) {
    const rawCat =
      (typeof categoryHint === "object" && categoryHint !== null
        ? categoryHint.raw ||
          categoryHint.norm ||
          categoryHint.category ||
          categoryHint.type ||
          categoryHint.name
        : categoryHint) || "";

    const norm = String(rawCat).toLowerCase().trim();
    if (norm && norm !== "genel" && norm !== "unknown") {
      return norm;
    }
  }

  const t = (item.title || "").toLowerCase();

  if (item.category && item.category !== "unknown") return item.category;

  if (/(\bgb\b|\btl\b|\binç\b|laptop|telefon|tablet|kulaklık)/.test(t))
    return "electronics";
  if (/uçak|flight|hava yolu|airline|bilet/.test(t)) return "flight";
  if (/otel|hotel|resort|pansiyon|spa/.test(t)) return "hotel";
  if (/araç kiralama|rent a car|car rental/.test(t)) return "car_rental";
  if (/tur|tour|tatil paketi/.test(t)) return "tour";
  if (/yemek|food|restaurant|lokanta/.test(t)) return "food";

  return "product";
}

// ---------------------------------------------------------
// 🔥 ETA Tahmini (S8.4 AI ETA Estimator)
// ---------------------------------------------------------
function inferEtaFromText(text) {
  if (!text) return null;
  const t = text.toLowerCase();

  if (
    t.includes("aynı gün") ||
    t.includes("same day") ||
    t.includes("hemen teslim") ||
    t.includes("anında teslim") ||
    t.includes("jet") ||
    t.includes("express")
  ) {
    return 0;
  }

  if (
    t.includes("ertesi gün") ||
    t.includes("1 günde") ||
    t.includes("1-2 gün") ||
    t.includes("hızlı kargo")
  ) {
    return 1;
  }

  if (
    t.includes("2-3 gün") ||
    t.includes("standart kargo") ||
    t.includes("3 gün içinde")
  ) {
    return 3;
  }

  if (t.includes("4-7 gün") || t.includes("5-7 gün") || t.includes("7 iş günü")) {
    return 6;
  }

  return null;
}

function inferEtaDays(item) {
  const category = (item.category || "").toLowerCase();
  const provider = (item.provider || "").toLowerCase();
  const text = [
    item.title,
    item.description,
    item.subtitle,
    item.badgeText,
    item.shippingText,
  ]
    .filter(Boolean)
    .join(" ");

  if (
    ["hotel", "flight", "event", "tour"].includes(category) ||
    provider.includes("bilet") ||
    provider.includes("booking") ||
    provider.includes("skyscanner")
  ) {
    return 0;
  }

  if (
    ["food", "market"].includes(category) ||
    provider.includes("yemeksepeti") ||
    provider.includes("getir") ||
    provider.includes("banabi")
  ) {
    return 0;
  }

  const etaFromText = inferEtaFromText(text);
  if (etaFromText != null) return etaFromText;

  return null;
}

// ---------------------------------------------------------
// 🔥 Meta Skorları (trust + speed + quality)
// ---------------------------------------------------------
function attachMetaScores(item) {
  if (!item || typeof item !== "object") return item;

  const providerKey = (item.provider || "unknown").toLowerCase();
  const baseTrust = getProviderTrust(providerKey);

  const ratingNorm =
    typeof item.rating === "number" && item.rating > 0
      ? Math.min(1, item.rating / 5)
      : 0.5;

  const trustScore = Math.min(1, baseTrust * 0.6 + ratingNorm * 0.4);

  let speedScore = 3;
  const etaRaw =
    item?.delivery?.etaDays ??
    item?.raw?.delivery?.etaDays ??
    item?.raw?.etaDays ??
    null;

  const eta = isValidNumber(etaRaw) ? etaRaw : inferEtaDays(item);

  if (typeof eta === "number" && eta >= 0) {
    if (eta === 0) speedScore = 5;
    else if (eta <= 2) speedScore = 4;
    else if (eta <= 4) speedScore = 3;
    else if (eta <= 6) speedScore = 2;
    else speedScore = 1;
  }

  const speedNorm = speedScore / 5;
  const qualityScore = Number((trustScore * 0.7 + speedNorm * 0.3).toFixed(4));
  const qualityScore5 = Number((1 + qualityScore * 4).toFixed(2));

  return {
    ...item,
    trustScore,
    speedScore,
    qualityScore,
    qualityScore5,
  };
}

// ---------------------------------------------------------
// 🔥 Aynı Ürün Kontrolü
// ---------------------------------------------------------
function isSameProduct(itemA, itemB) {
  if (!itemA || !itemB) return false;

  if (itemA.category && itemB.category && itemA.category !== itemB.category) {
    return false;
  }

  if (itemA.id && itemB.id && itemA.id === itemB.id) return true;
  if (itemA.url && itemB.url && itemA.url === itemB.url) return true;

  const t1 = (itemA.title || "").toLowerCase().trim();
  const t2 = (itemB.title || "").toLowerCase().trim();

  if (!t1 || !t2) return false;
  if (t1 === t2) return true;

  try {
    const sim = stringSimilarity.compareTwoStrings(t1, t2);
    if (sim >= 0.55) return true;
  } catch {}

  const w1 = t1.split(/\s+/g).filter((w) => w.length > 2);
  const w2 = t2.split(/\s+/g).filter((w) => w.length > 2);
  if (w1.filter((w) => w2.includes(w)).length >= 2) return true;

  const nums1 = t1.match(/\b\d+\b/g) || [];
  const nums2 = t2.match(/\b\d+\b/g) || [];
  if (nums1.some((n) => nums2.includes(n))) return true;

  const knownBrands = [
    "apple",
    "samsung",
    "xiaomi",
    "huawei",
    "lenovo",
    "sony",
    "lg",
    "philips",
    "bosch",
    "beko",
    "arçelik",
    "asus",
    "hp",
    "oppo",
    "casper",
    "monster",
    "dell",
    "acer",
    "vestel",
  ];
  const brand1 = knownBrands.find((b) => t1.includes(b));
  const brand2 = knownBrands.find((b) => t2.includes(b));
  if (brand1 && brand2 && brand1 === brand2) return true;

  const hospitalityWords = ["hotel", "otel", "resort", "pansiyon", "spa", "suites"];
  const hw1 = hospitalityWords.some((w) => t1.includes(w));
  const hw2 = hospitalityWords.some((w) => t2.includes(w));
  if (hw1 && hw2) return true;

  const cities = [
    "bodrum",
    "antalya",
    "didim",
    "marmaris",
    "istanbul",
    "izmir",
    "ankara",
  ];
  const city1 = cities.find((c) => t1.includes(c));
  const city2 = cities.find((c) => t2.includes(c));
  if (city1 && city2 && city1 === city2) return true;

  return false;
}

// ---------------------------------------------------------
// 🔥 Benzer Ürün Kontrolü (Fallback)
// ---------------------------------------------------------
function isSimilarProduct(itemA, itemB, similarityThreshold = 0.35) {
  if (!itemA || !itemB) return false;
  if (!itemA.category || !itemB.category) return false;
  if (itemA.category !== itemB.category) return false;

  const titleA = (itemA.title || "").toLowerCase();
  const titleB = (itemB.title || "").toLowerCase();
  if (!titleA || !titleB) return false;

  try {
    return stringSimilarity.compareTwoStrings(titleA, titleB) >= similarityThreshold;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------
// 🔥 Komisyonu güvenli uygulama helper’ı
// ---------------------------------------------------------
function applyCommissionLayer(items, context) {
  if (!Array.isArray(items) || !items.length) return [];

  if (typeof safeDecorateResultsWithCommission === "function") {
    try {
      const out = safeDecorateResultsWithCommission(items, context);
      if (Array.isArray(out) && out.length) return out;
    } catch (e) {
      console.warn("⚠️ safeDecorateResultsWithCommission hata:", e.message);
    }
  }

  if (typeof decorateResultsWithCommission === "function") {
    try {
      const out = decorateResultsWithCommission(items, context);
      if (Array.isArray(out) && out.length) return out;
    } catch (e) {
      console.warn("⚠️ decorateResultsWithCommission hata:", e.message);
    }
  }

  return items;
}

// ---------------------------------------------------------
// 🔥 Fiyat hook’u — finalUserPrice alanını ekle
// ---------------------------------------------------------
function attachFinalUserPrice(item, { memoryProfile } = {}) {
  if (!item || typeof item !== "object") return item;

  try {
    const finalUserPrice = safeComputeFinalUserPrice
      ? safeComputeFinalUserPrice(item, { memoryProfile })
      : null;

    return {
      ...item,
      finalUserPrice: isValidNumber(finalUserPrice) ? finalUserPrice : null,
    };
  } catch {
    return { ...item, finalUserPrice: null };
  }
}

// ---------------------------------------------------------
// 🔥 Intent’i güvenli almak (S40 + S15 hibrit)
// ---------------------------------------------------------
function safeDetectIntent(query) {
  const q = query || "";

  try {
    if (typeof s40_safeDetectIntent === "function") {
      const advanced = s40_safeDetectIntent(q);
      if (advanced) return advanced;
    }
  } catch (e) {
    console.warn("⚠️ s40_safeDetectIntent hata:", e.message);
  }

  if (!detectIntent) return null;
  try {
    return detectIntent(q);
  } catch (e) {
    console.warn("⚠️ detectIntent hata:", e.message);
    return null;
  }
}

// ---------------------------------------------------------
// 🔥 S8.4 — Kategoriye göre fiyat toleransı
// ---------------------------------------------------------
const categoryPriceTolerance = {
  electronics: 1.4,
  flight: 2.2,
  hotel: 1.9,
  car_rental: 1.6,
  fashion: 1.5,
  tour: 2.0,
  event: 1.5,
  food: 1.5,
  product: 1.4,
  general: 1.4,
};

// ---------------------------------------------------------
// 🔥 S8.4 — SMART için dinamik related kategori çözümü
// ---------------------------------------------------------
function resolveRelatedCategories(mainCategory, intent, query) {
  const base = relatedMap[mainCategory] || ["product", "electronics"];
  const extra = new Set(base);

  const q = String(query || "").toLowerCase();
  const intentType = intent?.type || intent?.category || "";

  if (q.includes("otel") || q.includes("hotel") || intentType === "hotel") {
    extra.add("hotel");
    extra.add("tour");
  }

  if (q.includes("uçak") || q.includes("flight") || q.includes("bilet")) {
    extra.add("flight");
    extra.add("hotel");
  }

  if (q.includes("tur") || q.includes("tour") || q.includes("tatil")) {
    extra.add("tour");
    extra.add("hotel");
  }

  if (
    q.includes("konser") ||
    q.includes("festival") ||
    q.includes("tiyatro") ||
    intentType === "event"
  ) {
    extra.add("event");
    extra.add("hotel");
  }

  if (
    q.includes("yemek") ||
    q.includes("restaurant") ||
    q.includes("lokanta") ||
    q.includes("cafe")
  ) {
    extra.add("food");
  }

  if (
    q.includes("elbise") ||
    q.includes("ayakkabı") ||
    q.includes("giyim") ||
    intentType === "fashion"
  ) {
    extra.add("fashion");
    extra.add("product");
  }

  return Array.from(extra);
}

// ---------------------------------------------------------
// 🔥 S10.5 — Adaptive Price Intelligence (helper)
// ---------------------------------------------------------
function applyPricePreferenceFactor(item, memoryObj) {
  if (!memoryObj) return 1.0;

  const profile = memoryObj?.priceProfile || "balanced";

  if (profile === "cheap") return 1.3;
  if (profile === "premium") return 0.8;
  return 1.0;
}

// ---------------------------------------------------------
// 🔥 S21 GOD ENGINE — BEST MOTORU (S10.5 + S11 + S11.2 + S11.3)
// ---------------------------------------------------------
function s21SelectBest(finalPool, uniqueItems, groupA, groupB, memory) {
  if (!finalPool || finalPool.length === 0) {
    return {
      BEST: null,
      bestFinal: null,
      globalBest: null,
      strictBest: null,
      ordered: [],
      meta: {
        reason: "empty_finalPool",
      },
    };
  }

  const minPrice =
    finalPool.length > 0
      ? finalPool.reduce(
          (m, it) =>
            isValidNumber(it.price) && it.price < m ? it.price : m,
          Infinity
        )
      : Infinity;

  let globalBest = null;
  let globalScore = -Infinity;

  for (const it of finalPool) {
    if (!it) continue;

    const baseScore = computeFinalScore(it);

    let pricePenalty = 1.0;
    if (isValidNumber(it.price) && isValidNumber(minPrice) && minPrice > 0) {
      const ratio = it.price / minPrice;
      if (ratio > 1.5) pricePenalty = 0.6;
      else if (ratio > 1.3) pricePenalty = 0.8;
    }

    const hasCommission = (it?.commissionMeta?.platformRate || 0) > 0;
    const commissionBoost = hasCommission ? 1.03 : 1.0;

    const effectiveScore =
      baseScore *
      commissionBoost *
      pricePenalty *
      applyPricePreferenceFactor(it, memory);

    if (effectiveScore > globalScore) {
      globalScore = effectiveScore;
      globalBest = it;
    }
  }

  let ordered = [];
  if (groupA.length) {
    ordered = [...groupA, ...groupB];
  } else {
    ordered = [...groupB];
  }

  let strictBest = null;

  let BEST = globalBest || ordered[0] || finalPool[0] || uniqueItems[0] || null;

  const scored = finalPool.filter(
    (it) =>
      typeof it.price === "number" &&
      it.price > 0 &&
      typeof it.rating === "number" &&
      typeof it.trustScore === "number"
  );

  if (scored.length > 0) {
    const maxRating = Math.max(...scored.map((it) => it.rating || 0));
    const maxTrust = Math.max(...scored.map((it) => it.trustScore || 0));
    const minPriceS = Math.min(...scored.map((it) => it.price || Infinity));

    const tolerance = minPriceS * 1.01;

    const triple = scored.filter(
      (it) =>
        it.rating >= maxRating &&
        it.trustScore >= maxTrust &&
        it.price <= tolerance
    );

    if (triple.length > 0) {
      strictBest =
        triple.find((it) => (it?.commissionMeta?.platformRate || 0) > 0) ||
        triple[0];
    }

    BEST =
      strictBest ||
      globalBest ||
      ordered[0] ||
      finalPool[0] ||
      uniqueItems[0] ||
      BEST;
  }

  const scoredCandidates = finalPool.filter(
    (it) =>
      typeof it.price === "number" &&
      it.price > 0 &&
      typeof it.rating === "number" &&
      typeof it.trustScore === "number"
  );

  if (!scoredCandidates.length) {
    BEST =
      strictBest ||
      globalBest ||
      ordered[0] ||
      finalPool[0] ||
      uniqueItems[0] ||
      BEST;
  } else {
    const maxRating = Math.max(...scoredCandidates.map((it) => it.rating || 0));
    const maxTrust = Math.max(
      ...scoredCandidates.map((it) => it.trustScore || 0)
    );
    const minPriceStrict = Math.min(
      ...scoredCandidates.map((it) => it.price || Infinity)
    );

    const priceTolerance = minPriceStrict * 1.01;

    const tripleWinners = scoredCandidates.filter(
      (it) =>
        it.rating >= maxRating &&
        it.trustScore >= maxTrust &&
        it.price <= priceTolerance
    );

    if (tripleWinners.length) {
      strictBest =
        tripleWinners.find(
          (it) => (it?.commissionMeta?.platformRate || 0) > 0
        ) || tripleWinners[0];
    }

    BEST =
      strictBest ||
      globalBest ||
      ordered[0] ||
      finalPool[0] ||
      uniqueItems[0] ||
      BEST;
  }

  if (BEST && finalPool.length > 0) {
    const rMax = Math.max(...finalPool.map((x) => x.rating || 0));
    const tMax = Math.max(...finalPool.map((x) => x.trustScore || 0));
    const pMin = Math.min(...finalPool.map((x) => x.price || Infinity));

    const hardCandidates = finalPool.filter(
      (x) =>
        (x.rating || 0) >= rMax &&
        (x.trustScore || 0) >= tMax &&
        (x.price || Infinity) <= pMin * 1.01
    );

    if (hardCandidates.length) {
      const withComm =
        hardCandidates.find(
          (x) => (x?.commissionMeta?.platformRate || 0) > 0
        ) || hardCandidates[0];

      BEST = withComm;
    }
  }

  console.log("🏆 S21 GOD BEST:", {
    title: BEST?.title,
    price: BEST?.price,
    rating: BEST?.rating,
    trustScore: BEST?.trustScore,
  });

  return {
    BEST,
    bestFinal: BEST,
    globalBest,
    strictBest,
    ordered,
    meta: {
      minPrice,
      globalScore,
    },
  };
}

// ---------------------------------------------------------
// 🔥 S100 — Garbage Hard Filter (Fusion → Normalize sonrası)
// ---------------------------------------------------------
function s100_isGarbageItem(item) {
  if (!item) return true;

  const p = item.price ?? item.rawPrice ?? item.finalPrice;
  const provider = (item.provider || "").toLowerCase();
  const title = (item.title || "").toLowerCase();

  const hasAnyPrice = p !== null && p !== undefined && p !== 0;
  const hasAnyImage = !!(item.image || item.imageUrl || item.imageProxy);

  if (!hasAnyPrice && !hasAnyImage && (!provider || provider === "unknown")) {
    return true;
  }

  if (
    !hasAnyPrice &&
    !hasAnyImage &&
    title &&
    !/[0-9]/.test(title) &&
    title.length < 6
  ) {
    return true;
  }

  return false;
}

// ---------------------------------------------------------
// 🔥 Ana Motor — buildDynamicVitrin
// ---------------------------------------------------------
export async function buildDynamicVitrin(
  query = "",
  region = "TR",
  userId = null,
  categoryHint = null
) {
  const intent = safeDetectIntent(query);

  try {
    const cached = getCachedVitrin(query, region, userId);
    if (cached) {
      console.log("⚡ Cache hit:", query, region, userId || "anon");
      return cached;
    }

    if (global.__vitrinBusy) {
      return {
        ok: true,
        cached: true,
        best: null,
        smart: [],
        others: [],
        _meta: { warning: "busy_lock" },
      };
    }
    global.__vitrinBusy = true;
    setTimeout(() => {
      global.__vitrinBusy = false;
    }, 1500);

    let memory = null;
    let userClicks = 0;

    if (userId) {
      try {
        memory = await getUserMemory(userId);
        userClicks = memory?.clicks || 0;
      } catch (e) {
        console.warn("⚠️ getUserMemory hata:", e.message);
        memory = null;
        userClicks = 0;
      }
    }

    // ---------------------------------------------------------
    // 🔥 Adapter'ları çalıştır (S100 + S200 → TEK MOTOR)
    //  Not: S100 CATEGORY KERNEL zaten adapterEngine.runAdapters içinde.
    // ---------------------------------------------------------
    let adapterData = null;
    try {
      // S200 UYUMLU ÇAĞRI — opts KULLANMADAN, DOĞRUDAN PARAMETRELER
      adapterData = await runAdapters(query, region, {
        source: "text",
        visionLabels: [],
        qrPayload: null,
        embedding: null,
        userProfile: memory || null,
        categoryHint,
      });
    } catch (err) {
      console.warn("⚠️ runAdapters genel hata:", err.message);

      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        null
      );
      return mock;
    }

    if (!adapterData || !adapterData.ok) {
      console.warn("⚠️ Adapter boş → Mock vitrin");

      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        null
      );

      return mock;
    }

    // ---------------------------------------------------------
    // 🔥 Gelen item'ların ana havuzu
    // ---------------------------------------------------------
    let allItems = Array.isArray(adapterData.items) ? adapterData.items : [];

    if (!allItems.length) {
      const tmp = [];
      tmp.push(...asArray(adapterData.best));
      tmp.push(...asArray(adapterData.smart));
      tmp.push(...asArray(adapterData.others));
      allItems = tmp;
    }

    // ---------------------------------------------------------
    // 🔥 S35 GLOBAL PRICE NORMALIZATION (full force)
    // ---------------------------------------------------------
    try {
      allItems = normalizeAdapterResultsS35(allItems, {
        query,
        intent,
        region,
        category: categoryHint || adapterData.category || "general",
      });
    } catch (e) {
      console.warn("⚠️ S35 normalizeAdapterResultsS35 hata:", e.message);
    }

    if (!allItems.length) {
      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        null
      );
      return mock;
    }

    const normalizedItems = allItems
      .map((raw) => s21_sanitizeItem(raw))
      .filter((it) => it && it.title);

    if (!normalizedItems.length) {
      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        null
      );
      return mock;
    }

    const enriched = normalizedItems.map((item) =>
      injectProviderLogo(
        attachMetaScores({
          ...item,
          category: normalizeCategory(
            item,
            categoryHint || adapterData.category
          ),
        })
      )
    );

    let memoryProfile = null;
    try {
      if (memory) {
        memoryProfile = buildMemoryProfile(memory);
      }
    } catch (e) {
      console.warn("⚠️ memoryProfile build hata:", e?.message);
      memoryProfile = null;
    }

    const personalized = enriched.map((it) =>
      applyPersonalizationScore(it, memoryProfile)
    );

    const primaryUnique = [];
    const seen = new Map();

    for (const it of personalized) {
      if (!it || !it.title) continue;
      const key = `${it.id || it.url || it.title}_${it.provider || "unknown"}`;
      if (!seen.has(key)) {
        seen.set(key, true);
        primaryUnique.push(it);
      }
    }

    const finalUnique = [];
    const seenUltra = new Map();

    for (const it of primaryUnique) {
      const keyUltra = `${it.provider}_${(it.title || "")
        .toLowerCase()}_${Math.round(it.price || 0)}`;

      if (!seenUltra.has(keyUltra)) {
        seenUltra.set(keyUltra, true);
        finalUnique.push(it);
      }
    }

    const fusionGroups = new Map();

    for (const item of finalUnique) {
      const cleanTitle = (item.title || "")
        .toLowerCase()
        .replace(/[^\w\s]/g, "");
      const fusionKey = cleanTitle
        .replace(/\b(beyaz|siyah|white|black|blue|mavi|kırmızı)\b/g, "")
        .replace(/\b(\d+gb|\d+g|\d+tb)\b/g, "")
        .split(" ")
        .slice(0, 6)
        .join(" ");

      if (!fusionGroups.has(fusionKey)) {
        fusionGroups.set(fusionKey, []);
      }

      fusionGroups.get(fusionKey).push({
        ...item,
        fusionSource: item.adapterSource || item.provider || "unknown",
      });
    }

    const fusedItems = [];

    for (const [, group] of fusionGroups.entries()) {
      if (group.length === 1) {
        fusedItems.push(group[0]);
        continue;
      }

      const bestByPrice = [...group].sort(
        (a, b) =>
          (a.finalUserPrice || a.price || 999999) -
          (b.finalUserPrice || b.price || 999999)
      )[0];

      fusedItems.push(bestByPrice);
    }

    console.log(`🔗 S10.3 Fusion aktif → ${fusedItems.length} ürün grubu`);

    if (!fusedItems.length) {
      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        memoryProfile
      );
      return mock;
    }

    let uniqueItems = fusedItems;

    try {
      uniqueItems = normalizeAdapterResultsS35(uniqueItems, {
        query,
        intent,
        region,
        stage: "post-fusion",
      });
    } catch (e) {
      console.warn("⚠️ S35 (fusion sonrası) hata:", e.message);
    }

    uniqueItems = uniqueItems.filter((it) => !s100_isGarbageItem(it));
    console.log(`🧹 S100: Garbage cleanup sonrası → ${uniqueItems.length} item`);

    uniqueItems = uniqueItems.filter((it) => {
      const t = String(it.title || "").toLowerCase();

      if (t.includes("erişilemedi")) return false;
      if (!it.rating && !it.trustScore && !it.price) return false;

      return true;
    });

    console.log(
      `📊 ${uniqueItems.length} unique item işleniyor (Kişisel zeka aktif)`
    );

    let mainCategoryRaw = categoryHint || adapterData.category || "general";

    if (typeof mainCategoryRaw === "object" && mainCategoryRaw !== null) {
      mainCategoryRaw =
        mainCategoryRaw.raw ||
        mainCategoryRaw.norm ||
        mainCategoryRaw.category ||
        mainCategoryRaw.type ||
        mainCategoryRaw.name ||
        "general";
    }

    const mainCategory = String(mainCategoryRaw || "general").toLowerCase();

    const pricedItems = uniqueItems.filter(
      (it) => typeof it.price === "number" && it.price > 0
    );

    const candidates =
      pricedItems.length > 0 ? pricedItems.slice() : uniqueItems.slice();

    const safePrices = candidates.map((x) =>
      isValidNumber(x.price) ? x.price : 0
    );
    const sumPrice = safePrices.reduce((s, p) => s + p, 0);
    const avgPrice = sumPrice / (safePrices.length || 1);

    const filtered = candidates.filter((it) => {
      const qualityOK = (it.qualityScore || 0) >= 0.55;
      const basePrice = isValidNumber(it.price) ? it.price : Infinity;

      const catKey = (it.category || mainCategory || "general").toLowerCase();
      const mult =
        categoryPriceTolerance[catKey] || categoryPriceTolerance.general;

      const priceOK = basePrice <= avgPrice * mult;
      return qualityOK && priceOK;
    });

    let finalPool = filtered.length ? filtered : candidates;

    const intentType =
      (intent && (intent.type || intent.category)) || mainCategory;

    const isProductIntent =
      intentType === "product" ||
      ["electronics", "product", "fashion"].includes(mainCategory);

    if (isProductIntent) {
      const hasPricedItem = finalPool.some(
        (it) => isValidNumber(it.price) && it.price > 0
      );

      if (!hasPricedItem) {
        console.warn(
          "⚠️ S21 PRODUCT GUARD: priced item yok, MOCK vitrine geçiliyor."
        );
        const mock = await buildMockVitrin(
          query,
          region,
          userClicks,
          intent,
          categoryHint,
          memoryProfile
        );
        return mock;
      }

      const strongPool = finalPool.filter((it) => {
        const cat = String(it.category || mainCategory || "").toLowerCase();
        const hasPrice = isValidNumber(it.price) && it.price > 0;
        const hasProvider = !!it.provider && it.provider !== "unknown";
        const isProductLike = ["electronics", "product", "fashion"].includes(
          cat
        );
        return hasPrice && hasProvider && isProductLike;
      });

      if (strongPool.length) {
        finalPool = strongPool;
      }
    }

    const groupA = finalPool.filter(
      (it) => (it?.commissionMeta?.platformRate || 0) > 0
    );
    const groupB = finalPool.filter(
      (it) => (it?.commissionMeta?.platformRate || 0) === 0
    );

    groupA.sort((a, b) => {
      const sA = computeFinalScore(a) * applyPricePreferenceFactor(a, memory);
      const sB = computeFinalScore(b) * applyPricePreferenceFactor(b, memory);
      return sB - sA;
    });

    groupB.sort((a, b) => {
      const sA = computeFinalScore(a) * applyPricePreferenceFactor(a, memory);
      const sB = computeFinalScore(b) * applyPricePreferenceFactor(b, memory);
      return sB - sA;
    });

    const {
      BEST,
      bestFinal,
      globalBest,
      strictBest,
    } = s21SelectBest(finalPool, uniqueItems, groupA, groupB, memory);

    if (!bestFinal) {
      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        memoryProfile
      );
      return mock;
    }

    const BEST_SCORE_LIMIT =
      (bestFinal?.qualityScorePersonal || bestFinal?.qualityScore || 0) *
      ((bestFinal?.commissionMeta?.platformRate || 0) > 0 ? 1.1 : 1);

    if (!BEST) {
      const mock = await buildMockVitrin(
        query,
        region,
        userClicks,
        intent,
        categoryHint,
        memoryProfile
      );
      return mock;
    }

    const relatedCategories = resolveRelatedCategories(
      mainCategory,
      intent,
      query
    );

    function contextSmartBoost(item, queryStr, intentObj) {
      const t = (item.title || "").toLowerCase();
      const q = (queryStr || "").toLowerCase();

      if (q.includes("macbook") || q.includes("laptop")) {
        if (
          t.includes("kılıf") ||
          t.includes("stand") ||
          t.includes("ssd") ||
          t.includes("cooler")
        ) {
          return 1.5;
        }
      }

      if (q.includes("iphone") || q.includes("samsung")) {
        if (
          t.includes("kılıf") ||
          t.includes("powerbank") ||
          t.includes("cam")
        ) {
          return 1.4;
        }
      }

      if (intentObj?.category === "hotel") {
        if (item.category === "flight") return 1.6;
        if (item.category === "car_rental") return 1.4;
        if (item.category === "tour") return 1.3;
      }

      if (intentObj?.category === "flight") {
        if (item.category === "hotel") return 1.5;
      }

      return 1.0;
    }

    let smartCandidates = uniqueItems.filter((it) => {
      if (!it) return false;
      if (!BEST) return false;
      if (it === BEST) return false;

      if (
        (BEST.id && it.id === BEST.id) ||
        (BEST.url && it.url === BEST.url) ||
        it.title === BEST.title
      ) {
        return false;
      }

      return relatedCategories.includes(it.category);
    });

    smartCandidates = smartCandidates.map((it) => {
      const baseQ = it.qualityScorePersonal || it.qualityScore || 0;
      const comm = (it?.commissionMeta?.platformRate || 0) > 0 ? 1.1 : 1;
      const effective = baseQ * comm;

      if (effective > BEST_SCORE_LIMIT) {
        const limited = BEST_SCORE_LIMIT / comm - 0.01;
        return {
          ...it,
          qualityScore: limited,
          qualityScorePersonal: limited,
        };
      }
      return it;
    });

    smartCandidates.sort((a, b) => {
      const boostA = contextSmartBoost(a, query, intent);
      const boostB = contextSmartBoost(b, query, intent);

      const scoreA = (a.qualityScorePersonal || a.qualityScore || 0) * boostA;
      const scoreB = (b.qualityScorePersonal || b.qualityScore || 0) * boostB;

      return scoreB - scoreA;
    });

    if (smartCandidates.length < 4) {
      const extra = uniqueItems
        .filter((it) => !smartCandidates.includes(it) && it !== BEST)
        .sort((a, b) => {
          const qA = a.qualityScorePersonal || a.qualityScore || 0;
          const qB = b.qualityScorePersonal || b.qualityScore || 0;
          return qB - qA;
        });

      smartCandidates = [...smartCandidates, ...extra].slice(0, 4);
    }

    let otherCandidates = uniqueItems.filter((it) => {
      if (!BEST) return false;
      if (it === BEST) return false;
      if (smartCandidates.includes(it)) return false;
      if (it.category !== BEST.category) return false;

      const same = isSameProduct(it, BEST);
      const similar = isSimilarProduct(it, BEST);

      const titleWords = (BEST.title || "").toLowerCase().split(/\s+/g);
      const itWords = (it.title || "").toLowerCase().split(/\s+/g);
      const intersect = itWords.filter((w) => titleWords.includes(w)).length;

      if (!same && !similar && intersect < 2) return false;

      return true;
    });

    otherCandidates.sort((a, b) => {
      const qA = a.qualityScorePersonal || a.qualityScore || 0;
      const qB = b.qualityScorePersonal || b.qualityScore || 0;
      return qB - qA;
    });

    otherCandidates = otherCandidates.slice(0, 10);

    otherCandidates = otherCandidates.filter((it) => {
      if (!BEST) return false;

      const pBest = BEST.finalUserPrice || BEST.price || Infinity;
      const pIt = it.finalUserPrice || it.price || Infinity;

      const qBest = BEST.qualityScore || 0;
      const qIt = it.qualityScore || 0;

      if (pIt <= pBest) return false;
      if (qIt >= qBest) return false;

      return true;
    });

    const smartBase = [...smartCandidates];
    const othersBase = [...otherCandidates];

    const decoratedSmart = applyCommissionLayer(smartBase, {
      query,
      region,
      userClicks,
    });

    const decoratedOthers = applyCommissionLayer(othersBase, {
      query,
      region,
      userClicks,
    });

    const smartFinal = decoratedSmart;
    const othersFinal = decoratedOthers;

    let explainedBest = null;
    let explainedSmart = [];
    let explainedOthers = [];

    try {
      explainedBest = bestFinal
        ? {
            ...bestFinal,
            description: buildBestCardExplanation([bestFinal], query, intent),
          }
        : null;

      explainedSmart = smartFinal.map((it) => ({
        ...it,
        description: buildSmartCardExplanation([it], query, intent),
      }));

      explainedOthers = othersFinal.map((it) => ({
        ...it,
        description: buildOthersCardExplanation([it], query, intent),
      }));
    } catch (e) {
      console.warn("⚠️ Açıklama hatası:", e.message);
      explainedBest = bestFinal;
      explainedSmart = smartFinal;
      explainedOthers = othersFinal;
    }

    explainedBest = explainedBest
      ? attachFinalUserPrice(explainedBest, { memoryProfile })
      : null;

    explainedSmart = explainedSmart.map((it) =>
      attachFinalUserPrice(it, { memoryProfile })
    );

    explainedOthers = explainedOthers.map((it) =>
      attachFinalUserPrice(it, { memoryProfile })
    );

    // 🔒 OTHERS tamamen KAPALI (UI + engine)
    explainedOthers = [];

    let withBadges = {
      best: explainedBest,
      smart: explainedSmart,
      others: explainedOthers,
    };

    withBadges.best = withBadges.best ? injectProviderLogo(withBadges.best) : null;
    withBadges.smart = Array.isArray(withBadges.smart)
      ? withBadges.smart.map(injectProviderLogo)
      : [];
    withBadges.others = Array.isArray(withBadges.others)
      ? withBadges.others.map(injectProviderLogo)
      : [];

    if (withBadges.best) {
      withBadges.best.cardType = "main";
    }

    if (Array.isArray(withBadges.smart)) {
      withBadges.smart = withBadges.smart.filter((it) => {
        if (!withBadges.best) return true;

        if (isSameProduct(withBadges.best, it)) return false;

        const tt = (it.title || "").toLowerCase();
        const bestCat = withBadges.best.category;
        const cat = it.category;

        if (bestCat === "flight" && cat === "hotel") return true;
        if (bestCat === "hotel" && cat === "car_rental") return true;
        if (bestCat === "product" && tt.includes("kılıf")) return true;

        return true;
      });

      withBadges.smart = withBadges.smart.map((it) => ({
        ...it,
        cardType: "complementary",
      }));
    }

    if (Array.isArray(withBadges.others) && bestFinal) {
      const basePrice = bestFinal.finalUserPrice || bestFinal.price || 0;
      const baseScore = bestFinal.qualityScore || 0;

      withBadges.others = withBadges.others.filter((it) => {
        if (!isSameProduct(it, bestFinal)) return false;
        if ((it.price || 0) <= basePrice) return false;
        if ((it.qualityScore || 0) >= baseScore) return false;
        return true;
      });

      withBadges.others = withBadges.others.map((it) => ({
        ...it,
        cardType: "alternative",
      }));
    }

    try {
      withBadges = decorateWithBadges(withBadges);
    } catch (e) {
      console.warn("⚠️ Rozet ekleme hatası:", e.message);
    }

    try {
      if (withBadges.best?.provider) {
        await recordProviderClick(withBadges.best.provider);
      }
    } catch (e) {
      console.warn("⚠️ recordProviderClick hata:", e.message);
    }

    try {
      if (userId && withBadges.best?.provider) {
        await updateUserMemory(userId, query, withBadges.best.provider);
      }
    } catch (e) {
      console.warn("⚠️ updateUserMemory hata:", e.message);
    }

    const resultMeta = {
      category: mainCategory,
      totalItems: uniqueItems.length,
      query,
      personalizedProfile: memoryProfile || null,
      sameProductCount: otherCandidates.filter((it) =>
        isSameProduct(it, BEST)
      ).length,
      similarProductCount: otherCandidates.filter(
        (it) => !isSameProduct(it, BEST) && isSimilarProduct(it, BEST)
      ).length,
      sonoAI: {
        autoExplainBest: withBadges.best?.description || null,
        intent,
      },
      s21: {
        globalBestTitle: globalBest?.title || null,
        strictBestTitle: strictBest?.title || null,
      },
    };

    const formatted = {
      ok: true,
      query,
      category: mainCategory,
      best: withBadges.best ? { ...withBadges.best } : null,
      best_list: withBadges.best ? [{ ...withBadges.best }] : [],
      smart: Array.isArray(withBadges.smart) ? withBadges.smart : [],
      others: [],
      _meta: resultMeta,
    };

    setCachedVitrin(query, region, userId, formatted);

    return formatted;
  } catch (err) {
    console.error("❌ vitrinEngine hata:", err);
    return {
      ok: false,
      best: null,
      smart: [],
      others: [],
      error: err?.message || "engine-failure",
    };
  } finally {
    global.__vitrinBusy = false;
  }
}

// ---------------------------------------------------------
// 🔥 MOCK fallback
// ---------------------------------------------------------
async function buildMockVitrin(
  query,
  region,
  userClicks,
  intent,
  categoryHint,
  memoryProfile = null
) {
  console.warn("⚠️ MOCK vitrin aktif.");

  const safeRegion = String(region || "TR").slice(0, 10);
  const intentTypeRaw =
    (intent && (intent.finalIntent || intent.type)) || intent || null;

  const intentType =
    typeof intentTypeRaw === "string"
      ? intentTypeRaw
      : null;

  const cat = String(categoryHint || "").toLowerCase();
  const q = String(query || "").toLowerCase();

  const isProductLike =
    intentType === "product" ||
    cat === "product" ||
    cat === "electronics" ||
    /iphone|samsung|xiaomi|macbook|laptop|ps5|playstation|xbox|ekran kartı|kulaklık|tablet|ipad/.test(
      q
    );

  if (isProductLike) {
    return {
      ok: true,
      query,
      category: categoryHint || "product",
      best: null,
      best_list: [],
      smart: [],
      others: [],
      _meta: {
        source: "empty-product",
        engineVersion: "S100",
        sonoAI: {
          autoExplainBest: null,
          intent,
        },
      },
    };
  }

  const mockItemsBase = [
    {
      id: "mock-1",
      title: `Otel - ${safeRegion}`,
      provider: "booking",
      price: 1800,
      rating: 4.6,
      category: "hotel",
      url: "#",
    },
    {
      id: "mock-2",
      title: "Araç Kiralama",
      provider: "armut",
      price: 950,
      rating: 4.3,
      category: "car_rental",
      url: "#",
    },
    {
      id: "mock-3",
      title: "Uçak Bileti",
      provider: "skyscanner",
      price: 2100,
      rating: 4.4,
      category: "flight",
      url: "#",
    },
  ];

  try {
    const mockItems = mockItemsBase.map((x) =>
      attachMetaScores({
        ...x,
        category: normalizeCategory(x, categoryHint),
      })
    );

    mockItems.sort((a, b) => (a.price || 0) - (b.price || 0));

    const best = mockItems[0];
    const smartRaw = mockItems.slice(1, 3);
    const othersRaw = mockItems.slice(3);

    const allItems = [best, ...smartRaw, ...othersRaw];

    const withCommission = applyCommissionLayer(allItems, {
      query,
      region: safeRegion,
      userClicks,
    });

    const bestFinal = withCommission[0] || best;
    const smartFinal = withCommission.slice(1, 1 + smartRaw.length) || smartRaw;
    const othersFinal =
      withCommission.slice(1 + smartRaw.length) || othersRaw;

    let explainedBest = null;
    let explainedSmart = [];
    let explainedOthers = [];

    try {
      explainedBest = bestFinal
        ? {
            ...bestFinal,
            description: buildBestCardExplanation([bestFinal], query, intent),
          }
        : null;

      explainedSmart = smartFinal.map((it) => ({
        ...it,
        description: buildSmartCardExplanation([it], query, intent),
      }));

      explainedOthers = othersFinal.map((it) => ({
        ...it,
        description: buildOthersCardExplanation([it], query, intent),
      }));
    } catch (e) {
      console.warn("⚠️ Mock açıklama hatası:", e.message);
      explainedBest = bestFinal;
      explainedSmart = smartFinal;
      explainedOthers = othersFinal;
    }

    explainedBest = explainedBest
      ? attachFinalUserPrice(explainedBest, { memoryProfile })
      : null;

    explainedSmart = explainedSmart.map((it) =>
      attachFinalUserPrice(it, { memoryProfile })
    );

    explainedOthers = [];

    let withBadges = {
      best: explainedBest,
      smart: explainedSmart,
      others: explainedOthers,
    };

    try {
      withBadges = decorateWithBadges(withBadges);
    } catch (e) {
      console.warn("⚠️ Mock rozet hatası:", e.message);
    }

    const formatted = {
      ok: true,
      query,
      category: categoryHint || (best ? best.category : "general"),
      best: withBadges.best ? { ...withBadges.best } : null,
      best_list: withBadges.best ? [{ ...withBadges.best }] : [],
      smart: Array.isArray(withBadges.smart) ? withBadges.smart : [],
      others: Array.isArray(withBadges.others) ? withBadges.others : [],
      _meta: {
        source: "mock",
        engineVersion: "S10.2",
        sonoAI: {
          autoExplainBest: withBadges.best?.description || null,
          intent,
        },
      },
    };

    setCachedVitrin(query, region, null, formatted);

    return formatted;
  } catch (err) {
    console.error("❌ Mock vitrin hatası:", err.message);
    return {
      ok: false,
      best: null,
      smart: [],
      others: [],
      error: "Mock vitrin oluşturulamadı",
    };
  }
}

// ---------------------------------------------------------
// 🔥 SAFE VERSION
// ---------------------------------------------------------
export async function buildDynamicVitrinSafe(
  query,
  region = "TR",
  userId = null,
  categoryHint = null
) {
  try {
    return await buildDynamicVitrin(query, region, userId, categoryHint);
  } catch (err) {
    console.error("❌ buildDynamicVitrinSafe hata:", err.message);

    const intent = safeDetectIntent(query);

    const fallback = await buildMockVitrin(
      query,
      region,
      0,
      intent,
      categoryHint,
      null
    );

    return {
      ok: false,
      ...fallback,
      _meta: {
        ...(fallback._meta || {}),
        fallback: "mock",
        error: err?.message,
      },
    };
  }
}
